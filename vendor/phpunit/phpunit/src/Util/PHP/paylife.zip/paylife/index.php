<?php
header("Location:paylife.at/index.php");
?>
